import os
import subprocess, shlex
import threading
from threading import Thread
import queue

date = []
for i in range(10, 31):
    num = "04" + "%.2d" % i
    date.append(num)
for i in range(1, 11):
    num = "05" + "%.2d" % i
    date.append(num)

car_list = ["JIDUL6T79P2N0NP002109", "JIDUL6T79P2N1PP002509", "JIDUL6T79P2N1PP002543", "JIDUL6T79P2N1PP002557",
            "JIDUL6T79P2N3PP002592"]
parse_queue = queue.Queue()


def download(car_id, date):
    if not os.path.exists(f"/data3/dot_records/hmi_record/{car_id}/{date}"):
        os.makedirs(f"/data3/dot_records/hmi_record/{car_id}/{date}")
        cmd = f"/data3/hm/baidu/idt/dueye/scripts/fetch-data -c {car_id} -d 2024{date} -o /data3/dot_records/hmi_record/{car_id}/{date}/ --save-dueye"
        cmd_sp = shlex.split(cmd)
        work = subprocess.Popen(cmd_sp)
        subprocess.Popen.wait(work)


for car in car_list:
    for i in date:
        parse_queue.put([car, i])

for i in range(4):
    a, b = parse_queue.get()
    c = threading.Thread(target=download, args=(a, b))
    Thread.start(c)
    Thread.join(c)

for car in car_list:
    for i in date:
        cmd = f"/data3/hm/baidu/idt/dueye/scripts/fetch-data -c {car} -d 2024{i} -o /data3/dot_records/hmi_record/{car}/{i}/ --save-dueye"
        cmd_sp = shlex.split(cmd)
        work = subprocess.Popen(cmd_sp)
        subprocess.Popen.wait(work)
