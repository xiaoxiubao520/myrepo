import sys, queue, threading,os,time
import subprocess, shlex


def download(inp_queue):
    while not inp_queue.empty():
        record,JIDU = inp_queue.get()
        save_dir = sys.argv[2]
        other_params = str(sys.argv[1:]).strip("[]").replace(",", " ").replace("'","")
        cmd = f"python /data3/hm/baidu/idt/dueye/tools/visualize_pipeline.py {record} /data1/xieshufu/baidu/adu/params/{JIDU}/latest/ --target_dir {save_dir} {other_params}"
        cmd_sp = shlex.split(cmd)
        work = subprocess.Popen(cmd_sp)
        work.wait()
if __name__ == "__main__":
    v = []
    inp = queue.Queue()
    record_path = sys.argv[1]
    record_list = os.listdir(record_path)
    start = time.time()
    for i in record_list:
        if i.find(".record")>=0:
           record = os.path.join(record_path,i)
           JIDU = "JIDU"+i.strip().split("_")[1][-4:]
           inp.put([record,JIDU])
    for i in range(4):
        a = threading.Thread(target=download, args=(inp,))
        a.start()
        v.append(a)
    for i in v:
        i.join()
    end = time.time()
    print(f"time:{(end-start)/60}min")
