import pandas as pd, matplotlib.pyplot as plt


def read_version(version_file):
    execute = {}
    data = pd.read_excel(version_file, header=1)
    # execute = {"CIPV_VEH_LOST": data[data["事件类型"] == "CIPV_VEH_LOST"],
    #            "CIPV_POS_EXCEPTION_VEH": data[data["事件类型"] == "CIPV_POS_EXCEPTION_VEH"],
    #            "CIPV_POS_SHIFT_DIFF_VEH": data[data["事件类型"] == "CIPV_POS_SHIFT_DIFF_VEH"],
    #            "CIPV_THETA_DIFF_VEH": data[data["事件类型"] == "CIPV_THETA_DIFF_VEH"],
    #            "LARGE_VEHICLE_POS_EXCEPTION": data[data["事件类型"] == "LARGE_VEHICLE_POS_EXCEPTION"],
    #            "LARGE_VEHICLE_POS_SHIFT_DIFF": data[data["事件类型"] == "LARGE_VEHICLE_POS_SHIFT_DIFF"],
    #            "LARGE_VEHICLE_THETA_DIFF": data[data["事件类型"] == "LARGE_VEHICLE_THETA_DIFF"],
    #            "NarrowCIPV":data[data["事件类型"] == "NarrowCIPV"]}
    # return execute
    li = set(data["事件类型"])
    for i in li:
        execute.update({i: data[data["事件类型"] == i]})

    return execute

def huitu(km_file, execute):
    data2 = pd.read_excel(km_file, header=1)
    for i, j in execute.items():
        version = j["版本"]
        dt = version.value_counts()
        x = dt.keys().tolist()
        y = dt.values
        lb = list()
        for k, l in zip(x, y):
            lb.append([k, l])
        sort = sorted(lb, key=lambda x: int("".join(x[0].split("."))))
        x = list(map(lambda a: a[0], sort))
        y = list(map(lambda a: a[1], sort))
        plt.figure()
        plt.bar(x, y, color='skyblue', edgecolor='black', label="count")
        plt.xticks(x, rotation=-90, labels=x)
        ls = [t for i in range(20) for t in [0.001, 0.19]]
        for a, b, c in zip(x, y, ls):
            km = data2[data2["version"] == a]["自动驾驶里程"]
            km_num = km.str[:-2].astype(float)
            km_sum = km_num.sum()
            if not km_sum:
                continue
            km_100 = b / km_sum * 100
            if i == "CIPV_VEH_LOST" or i == "NarrowCIPV":
                plt.text(a, b + c, "%d" % b, ha="center", va="bottom", fontsize=6, color="black",
                         fontweight='bold')
                # plt.text(a, b - 0.4, "%d" % b, ha="center", va="bottom", fontsize=6, color="black", fontweight='bold')
                # plt.text(a, b - 10.0, "%d" % km_sum, ha="center", va="bottom", fontsize=6, color="black",
                #          fontweight='bold')
            else:
                plt.text(a, b + 0.01, "%d" % b, ha="center", va="bottom", fontsize=6, color="black",
                         fontweight='bold')
                # plt.text(a, b - 0.15, "%d" % b, ha="center", va="bottom", fontsize=6, color="black",
                # fontweight='bold')
                # plt.text(a, b - 0.60, "%d" % km_sum, ha="center", va="bottom", fontsize=6, color="black",
                #          fontweight='bold')
            plt.grid(axis='y', linestyle='--', linewidth=0.5)
            plt.title(i, fontweight="bold")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"./picture/{i}.jpg")

def zhexian(km_file, execute):
    data2 = pd.read_excel(km_file,sheet_name="里程",header=1)
    for i, j in execute.items():
        version = j["版本"]
        dt = version.value_counts()
        x = dt.keys().tolist()
        y = dt.values
        lb = list()
        for k, l in zip(x, y):
            lb.append([k, l])
        sort = sorted(lb, key=lambda x: int("".join(x[0].split("."))))
        x = list(map(lambda a: a[0], sort))
        y = list(map(lambda a: a[1], sort))
        plt.figure()
        km_list = []
        for a, b in zip(x, y):
            km = data2[data2["version"] == a]["自动驾驶里程"]
            km_num = km.str[:-2].astype(float)
            km_sum = km_num.sum()
            if not km_sum:
                km_100 = 0
            else:
                km_100 = b / km_sum * 100
            km_list.append(km_100)
        plt.plot(x, km_list, color='skyblue', label="count")
        plt.xticks(x, rotation=-90, labels=x)
            # if i == "CIPV_VEH_LOST" or i == "NarrowCIPV":
            #     plt.text(a, b + c, "%.3f" % km_100, ha="center", va="bottom", fontsize=6, color="black",
            #              fontweight='bold')
            #     # plt.text(a, b - 0.4, "%d" % b, ha="center", va="bottom", fontsize=6, color="black", fontweight='bold')
            #     # plt.text(a, b - 10.0, "%d" % km_sum, ha="center", va="bottom", fontsize=6, color="black",
            #     #          fontweight='bold')
            # else:
            #     plt.text(a, b + 0.01, "%.3f" % km_100, ha="center", va="bottom", fontsize=6, color="black",
            #              fontweight='bold')
                # plt.text(a, b - 0.15, "%d" % b, ha="center", va="bottom", fontsize=6, color="black",
                # fontweight='bold')
                # plt.text(a, b - 0.60, "%d" % km_sum, ha="center", va="bottom", fontsize=6, color="black",
                #          fontweight='bold')
        plt.grid(axis='y', linestyle='--', linewidth=0.5)
        plt.title(i, fontweight="bold")
        plt.legend()
        plt.tight_layout()
        plt.savefig(f"./picture/{i}_触发次数.jpg")

def main():
    execute = read_version("/Users/v_huangmin05/Downloads/通用打点数据_1716866342368.xlsx")
    # huitu("/Users/v_huangmin05/Downloads/里程 (4).xlsx", execute)
    zhexian("/Users/v_huangmin05/Downloads/通用打点数据_1716866342368.xlsx", execute)

if __name__ == "__main__":
    main()
