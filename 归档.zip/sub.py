from pyecharts.charts import Line,Grid
from pyecharts import options as opts
from pyecharts.globals import ThemeType
df = open("/Users/v_huangmin05/Downloads/11.csv")

# 创建一个折线图对象  
line = Line()
# 添加X轴和Y轴的数据  
line.add_xaxis(["4/15~4/21",
                "4/22~4/28",
                "4/29~5/5",
                "5/6~5/12",
                "5/13~5/19",
                "5/20~5/26"
                ])
for i in df.read().splitlines():
    par = i.strip().split(",")
    ex = par[0]
    data = par[1:]
    data = list(map(lambda x:float(x),data))
    line.add_yaxis(f"{ex}",data,linestyle_opts=opts.LineStyleOpts(width=4),label_opts=opts.LabelOpts(is_show=False))

line.set_global_opts(title_opts=opts.TitleOpts(title="Master版本各事件触发打点频次",pos_left="center"),legend_opts=opts.LegendOpts(orient='vertical', pos_right='center',pos_top='75%'),
                     xaxis_opts=opts.AxisOpts(
                         splitline_opts=opts.SplitLineOpts(is_show=False)
                     ))
g = Grid()
g.add(line,grid_opts=opts.GridOpts(pos_bottom="30%"))
# 渲染图表为HTML文件  
g.render()
