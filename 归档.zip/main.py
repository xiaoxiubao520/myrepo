37477

43048

11364

46519

53306


132372

from pyecharts.charts import Line,Grid
from pyecharts import options as opts
from pyecharts.globals import ThemeType
df = open("/Users/v_huangmin05/Downloads/jk.csv")

# 创建一个折线图对象
line = Line()
# 添加X轴和Y轴的数据
line.add_xaxis(["4/15~4/21",
                "4/22~4/28",
                "4/29~5/5",
                "5/6~5/12",
                "5/13~5/19",
                "5/20~5/26"
                ])
8809,
19778,
5062,
20800,
26336,
24847

line.add_yaxis("自动驾驶里程", [37477,
43048,
11364,
46519,
53306,
132372], linestyle_opts=opts.LineStyleOpts(width=5), label_opts=opts.LabelOpts(is_show=False))
line.add_yaxis("Master",[8809,
19778,
5062,
20800,
26336,
24847],linestyle_opts=opts.LineStyleOpts(width=5),label_opts=opts.LabelOpts(is_show=False))
line.add_yaxis("RB",[6643,
7029,
1655,
10054,
17559,
99934
],linestyle_opts=opts.LineStyleOpts(width=5),label_opts=opts.LabelOpts(is_show=False))
line.set_global_opts(title_opts=opts.TitleOpts(title="4-5月份自动驾驶里程统计",pos_left="center"),legend_opts=opts.LegendOpts( pos_right='center',pos_top='75%'),xaxis_opts=opts.AxisOpts(
        splitline_opts=opts.SplitLineOpts(is_show=False)  # 这里是关键设置
))
g = Grid()
g.add(line,grid_opts=opts.GridOpts(pos_bottom="30%"))
# 渲染图表为HTML文件
g.render()
